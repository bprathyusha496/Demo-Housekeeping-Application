package com.xen.housekeeping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Application01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
