package com.xen.housekeeping.service;

import java.util.List;

import com.xen.housekeeping.dto.ScheduleDTO;

public interface ScheduleService {

	List<ScheduleDTO> getAllSchedules();
    ScheduleDTO createSchedule(ScheduleDTO scheduleDTO);
    List<ScheduleDTO> getSchedulesByTaskId(Long taskId);

}
