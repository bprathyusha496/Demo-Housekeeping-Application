package com.xen.housekeeping.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xen.housekeeping.Entity.Availability;
import com.xen.housekeeping.Entity.Staff;
import com.xen.housekeeping.dto.StaffDTO;
import com.xen.housekeeping.repository.StaffRepository;

@Service
public class StaffServiceImpl implements StaffService {

	@Autowired
	private StaffRepository staffRepository;
	private final ModelMapper modelMapper;

	public StaffServiceImpl(StaffRepository staffRepository, ModelMapper modelMapper) {
		super();
		this.staffRepository = staffRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<StaffDTO> getAllStaff() {
		List<Staff> staffList = staffRepository.findAll();
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public StaffDTO getStaffById(Long id) {
		Optional<Staff> staffOptional = staffRepository.findById(id);
		return staffOptional.map(this::convertToDTO).orElse(null);
	}

	@Override
	public StaffDTO createStaff(StaffDTO staffDTO) {
		Staff staff = convertToEntity(staffDTO);
		Staff savedStaff = staffRepository.save(staff);
		return convertToDTO(savedStaff);
	}

	@Override
	public StaffDTO updateStaff(Long id, StaffDTO staffDTO) {
		Optional<Staff> staffOptional = staffRepository.findById(id);
		if (staffOptional.isPresent()) {
			Staff staffToUpdate = staffOptional.get();
			staffToUpdate.setName(staffDTO.getName());
			staffToUpdate.setRole(staffDTO.getRole());
			// Update other fields as needed
			Staff updatedStaff = staffRepository.save(staffToUpdate);
			return convertToDTO(updatedStaff);
		} else {
			return null;
		}
	}

	@Override
	public boolean deleteStaff(Long id) {
		if (staffRepository.existsById(id)) {
			staffRepository.deleteById(id);
			return true;
		} else {
			return false;
		}
	}

	private StaffDTO convertToDTO(Staff staff) {
		return modelMapper.map(staff, StaffDTO.class);
	}

	private Staff convertToEntity(StaffDTO staffDTO) {
		return modelMapper.map(staffDTO, Staff.class);
	}

	@Override
	public List<StaffDTO> getStaffByRole(String role) {
		List<Staff> staffList = staffRepository.findByRole(role);
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<StaffDTO> getStaffBySkill(String skill) {
		List<Staff> staffList = staffRepository.findBySkillsContaining(skill);
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}
	@Override
	public List<StaffDTO> getStaffByStatus(String status) {
		List<Staff> staffList = staffRepository.findByStatus(status);
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<StaffDTO> getStaffByWorkingHours(int hours) {
		List<Staff> staffList = staffRepository.findByWorkingHours(hours);
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<StaffDTO> getStaffByLocation(String location) {
		List<Staff> staffList = staffRepository.findByLocation(location);
		return staffList.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/*
	 * @Override public List<Staff> findByAvailability(LocalDate date) { return
	 * staffRepository.findByAvailability(date); }
	 */
	/*
	 * @Override public List<StaffDTO>
	 * findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate
	 * startDate, LocalDate endDate) { List<StaffDTO> staffList =
	 * staffRepository.findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(
	 * startDate, endDate); return staffList.stream() .map(this::convertToDTO)
	 * .collect(Collectors.toList()); }
	 */
	/*
	 * @Override public List<StaffDTO>
	 * findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate
	 * startDate, LocalDate endDate) { return
	 * staffRepository.findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(
	 * startDate, endDate); }
	 */

	/*
	 * @Override public List<StaffDTO> getAvailableStaff(LocalDate date, LocalTime
	 * time) { List<Staff> allStaff = staffRepository.findAll();
	 * 
	 * // Filter staff members based on availability List<Staff> availableStaff =
	 * allStaff.stream() .filter(staff -> isStaffAvailable(staff, date, time))
	 * .collect(Collectors.toList());
	 * 
	 * // Convert entities to DTOs return availableStaff.stream()
	 * .map(this::convertToDTO) .collect(Collectors.toList()); }
	 */

	private boolean isStaffAvailable(Staff staff, LocalDate date, LocalTime time) {
		// Assuming staff availability is stored in the database or some external system

		// Retrieve the availability schedule for the staff member
		Availability availability = staff.getAvailability();

		// Check if the staff member is available on the given date and time
		// Implement your logic here based on your availability model
		// For example, check if the staff member has availability for the given date
		// and time slot

		// Example logic:
		// Check if the staff member's availability schedule contains the given date
		boolean isAvailableOnDate = availability.getAvailableDates().contains(date);

		// Check if the staff member's availability schedule contains the given time
		// slot
		boolean isAvailableAtTime = availability.getAvailableTimes().contains(time);

		// Return true if the staff member is available on the given date and time
		return isAvailableOnDate && isAvailableAtTime;
	}

	

}