package com.xen.housekeeping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.xen.housekeeping.Entity.Client;

@Repository
public interface ClientRepository extends JpaRepository<Client, Long>{

	List<Client> findByLocation(String location);
	List<Client> findByOutstandingPaymentsGreaterThan(Double amount);
//	@Query("SELECT c FROM Client c WHERE NOT EXISTS (SELECT 1 FROM Task t WHERE t.client = c AND t.status = 'COMPLETED' AND t.feedback IS NOT NULL)")
//	List<Client> findClientsWithNoFeedback();
	
	@Query("SELECT c FROM Client c WHERE NOT EXISTS (SELECT t FROM Task t WHERE t.client = c AND t.feedback IS NOT NULL)")
    List<Client> findClientsWithNoFeedback();
	


}
