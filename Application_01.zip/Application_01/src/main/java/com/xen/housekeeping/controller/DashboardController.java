package com.xen.housekeeping.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DashboardController {

	@GetMapping("/dashboard")
    public String getDashboard() {
        // Logic to fetch and return personalized dashboard data
        return "Dashboard data";
    }
}
