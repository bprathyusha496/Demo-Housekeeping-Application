package com.xen.housekeeping.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xen.housekeeping.dto.TaskDTO;
import com.xen.housekeeping.service.TaskService;

@RestController
@RequestMapping("/tasks")
public class TaskController {

	@Autowired
	private TaskService taskService;

	@GetMapping
	public List<TaskDTO> getAllTasks() {
		return taskService.getAllTasks();
	}

	@PostMapping
	public TaskDTO createTask(@RequestBody TaskDTO taskDTO) {
		return taskService.createTask(taskDTO);
	}

	// Retrieve tasks assigned to a specific staff member.
	@GetMapping("/staff/{staffId}")
	public List<TaskDTO> getTasksByStaffId(@PathVariable Long staffId) {
		return taskService.getTasksByStaffId(staffId);
	}

	// Retrieve tasks assigned to a specific client.
	@GetMapping("/client/{clientId}")
	public List<TaskDTO> getTasksByClientId(@PathVariable Long clientId) {
		return taskService.getTasksByClientId(clientId);
	}

	// Retrieve tasks completed within a specific time period.
	@GetMapping("/completed/{startDate}/{endDate}")
	public List<TaskDTO> getTasksCompletedBetween(@PathVariable LocalDate startDate, @PathVariable LocalDate endDate) {
		return taskService.getTasksCompletedBetween(startDate, endDate);
	}
	// Retrieve tasks completed by a specific staff member within a given time range.

	@GetMapping("/completed/staff/{staffId}")
	public List<TaskDTO> getTasksCompletedByStaffWithinRange(@PathVariable Long staffId,
			@RequestParam("startDate") LocalDate startDate, @RequestParam("endDate") LocalDate endDate) {
		return taskService.getTasksCompletedByStaffWithinRange(staffId, startDate, endDate);
	}

	// Retrieve the total number of tasks completed by each staff member.
	@GetMapping("/completed/count/staff")
	public Map<Long, Long> getTotalCompletedTasksByStaff() {
		return taskService.getTotalCompletedTasksByStaff();
	}

	// Retrieve tasks that are overdue.

	@GetMapping("/overdue")
	public List<TaskDTO> getOverdueTasks() {
		return taskService.getOverdueTasks();
	}

	// Retrieve the average rating of completed tasks for each client.

	@GetMapping("/completed/ratings/average")
	public Map<Long, Double> getAverageRatingsByClient() {
		return taskService.getAverageRatingsByClient();
	}

}
