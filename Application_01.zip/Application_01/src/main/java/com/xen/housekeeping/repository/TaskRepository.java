package com.xen.housekeeping.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.xen.housekeeping.Entity.Task;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

	List<Task> findByStaffId(Long staffId);

	List<Task> findByClientId(Long clientId);

	List<Task> findByCompletionDateBetween(LocalDate startDate, LocalDate endDate);

	List<Task> findByStaffIdAndCompletionDateBetween(Long staffId, LocalDate startDate, LocalDate endDate);

	@Query("SELECT t.staff.id, COUNT(t) FROM Task t WHERE t.status = 'COMPLETED' GROUP BY t.staff.id")
	List<Object[]> findTotalCompletedTasksByStaff();

	@Query("SELECT t FROM Task t WHERE t.dueDate < CURRENT_DATE AND t.status = 'PENDING'")
	List<Task> findOverdueTasks();

	@Query("SELECT t.client.id, AVG(t.rating) FROM Task t WHERE t.status = 'COMPLETED' GROUP BY t.client.id")
	List<Object[]> findAverageRatingsByClient(); 
   
//	List<Task>findByClientLocation(String location);

}
