package com.xen.housekeeping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xen.housekeeping.dto.ClientDTO;
import com.xen.housekeeping.service.ClientService;

@RestController
@RequestMapping("/clients")
public class ClientController {

	@Autowired
	private ClientService clientService;

	@GetMapping
	public List<ClientDTO> getAllClients() {
		return clientService.getAllClients();
	}

	@PostMapping
	public ClientDTO createClient(@RequestBody ClientDTO clientDTO) {
		return clientService.createClient(clientDTO);
	}

	// Retrieve clients based on their location.
	@GetMapping("/location/{location}")
	public List<ClientDTO> getClientsByLocation(@PathVariable String location) {
		return clientService.getClientsByLocation(location);
	}

	// Retrieve clients with outstanding payments.
	@GetMapping("/outstanding-payments")
	public List<ClientDTO> getClientsWithOutstandingPayments() {
		return clientService.getClientsWithOutstandingPayments();
	}

	// Retrieve clients who have not provided feedback on completed tasks.

	@GetMapping("/no-feedback")
	public List<ClientDTO> getClientsWithNoFeedback() {
		return clientService.getClientsWithNoFeedback();
	}

}
