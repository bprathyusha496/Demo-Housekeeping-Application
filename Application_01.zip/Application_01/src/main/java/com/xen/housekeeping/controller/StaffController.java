package com.xen.housekeeping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xen.housekeeping.dto.StaffDTO;
import com.xen.housekeeping.service.StaffService;

@RestController
@RequestMapping("/staff")
public class StaffController {

	@Autowired
	private StaffService staffService;

	@GetMapping
	public ResponseEntity<List<StaffDTO>> getAllStaff() {
		List<StaffDTO> staffList = staffService.getAllStaff();
		return ResponseEntity.ok(staffList);
	}

	@GetMapping("/{id}")
	public ResponseEntity<StaffDTO> getStaffById(@PathVariable Long id) {
		StaffDTO staffDTO = staffService.getStaffById(id);
		if (staffDTO != null) {
			return ResponseEntity.ok(staffDTO);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@PostMapping
	public ResponseEntity<StaffDTO> createStaff(@RequestBody StaffDTO staffDTO) {
		StaffDTO createdStaff = staffService.createStaff(staffDTO);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdStaff);
	}

	@PutMapping("/{id}")
	public ResponseEntity<StaffDTO> updateStaff(@PathVariable Long id, @RequestBody StaffDTO staffDTO) {
		StaffDTO updatedStaff = staffService.updateStaff(id, staffDTO);
		if (updatedStaff != null) {
			return ResponseEntity.ok(updatedStaff);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteStaff(@PathVariable Long id) {
		boolean deleted = staffService.deleteStaff(id);
		if (deleted) {
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	// Retrieve staff members by their roles.
	@GetMapping("/role/{role}")
	public List<StaffDTO> getStaffByRole(@PathVariable String role) {
		return staffService.getStaffByRole(role);
	}

	// Retrieve staff members with specific skills.
	@GetMapping("/skills/{skill}")
	public List<StaffDTO> getStaffBySkill(@PathVariable String skill) {
		return staffService.getStaffBySkill(skill);
	}

	// Retrieve staff members by their employment status.
	@GetMapping("/status/{status}")
	public List<StaffDTO> getStaffByStatus(@PathVariable String status) {
		return staffService.getStaffByStatus(status);
	}

	// Retrieve staff members by their working hours.
	@GetMapping("/working-hours/{hours}")
	public List<StaffDTO> getStaffByWorkingHours(@PathVariable int hours) {
		return staffService.getStaffByWorkingHours(hours);
	}

	// Retrieve staff members by their location.
	@GetMapping("/location/{location}")
	public List<StaffDTO> getStaffByLocation(@PathVariable String location) {
		return staffService.getStaffByLocation(location);
	}

	// Retrieve staff members based on their availability.

	/*
	 * @GetMapping("/availability/{date}") public List<Staff>
	 * getAvailableStaff(@PathVariable LocalDate date) { return
	 * staffService.getAvailableStaff(date); }
	 */

	// Retrieve staff members available for a specific date and time.
	/*
	 * @GetMapping("/staff") public List<StaffDTO> getStaffByAvailability(
	 * 
	 * @RequestParam("startDate") LocalDate startDate,
	 * 
	 * @RequestParam("endDate") LocalDate endDate) { // Call the service method to
	 * retrieve staff by availability List<StaffDTO> staffDTOList =
	 * staffService.findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(
	 * startDate, endDate);
	 * 
	 * // Optionally, you can do further processing or validation here
	 * 
	 * return staffDTOList; }
	 */
	/*
	 * @GetMapping("/availability") public List<StaffDTO>
	 * getAvailableStaff(@RequestParam @DateTimeFormat(iso =
	 * DateTimeFormat.ISO.DATE) LocalDate start, @RequestParam @DateTimeFormat(iso =
	 * DateTimeFormat.ISO.TIME) LocalTime time) { return
	 * staffService.findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(
	 * start, start) }
	 */

}
