package com.xen.housekeeping.security;

public class SecurityConfig {

}
