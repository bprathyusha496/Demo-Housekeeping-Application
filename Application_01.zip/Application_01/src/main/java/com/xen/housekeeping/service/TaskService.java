package com.xen.housekeeping.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.xen.housekeeping.dto.TaskDTO;

public interface TaskService {

	List<TaskDTO> getAllTasks();
    TaskDTO createTask(TaskDTO taskDTO);
    List<TaskDTO> getTasksByStaffId(Long staffId);
    List<TaskDTO> getTasksByClientId(Long clientId);
    List<TaskDTO> getTasksCompletedBetween(LocalDate startDate, LocalDate endDate);
    List<TaskDTO> getTasksCompletedByStaffWithinRange(Long staffId, LocalDate startDate, LocalDate endDate);
	Map<Long, Long> getTotalCompletedTasksByStaff();  
	List<TaskDTO>getOverdueTasks(); 
	Map<Long, Double> getAverageRatingsByClient();
	 
}
