package com.xen.housekeeping.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.xen.housekeeping.Entity.Staff;
import com.xen.housekeeping.dto.StaffDTO;

public interface StaffService {
	
	List<StaffDTO> getAllStaff();
	StaffDTO getStaffById(Long id);
	StaffDTO createStaff(StaffDTO staffDTO);
	StaffDTO updateStaff(Long id, StaffDTO staffDTO);
	boolean deleteStaff(Long id);
	List<StaffDTO> getStaffByRole(String role);
	List<StaffDTO> getStaffBySkill(String skill);
	List<StaffDTO> getStaffByStatus(String status);
	List<StaffDTO> getStaffByWorkingHours(int hours);
	List<StaffDTO> getStaffByLocation(String location);
	
//	List<Staff> findByAvailability(LocalDate date);
//	List<StaffDTO> getAvailableStaff(LocalDate date, LocalTime time);
//	List<StaffDTO> findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate startDate, LocalDate endDate);
	

	

}
