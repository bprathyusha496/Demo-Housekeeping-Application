package com.xen.housekeeping.Entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Availability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(mappedBy = "availability",cascade = CascadeType.ALL)
    private Staff staff;

    private LocalDate startDate;
    private LocalDate endDate;
    @ElementCollection
    @CollectionTable(name = "available_dates", joinColumns = @JoinColumn(name = "availability_id"))
    @Column(name = "available_date")
    private Set<LocalDate> availableDates = new HashSet<>();

    @ElementCollection
    @CollectionTable(name = "available_times", joinColumns = @JoinColumn(name = "availability_id"))
    @Column(name = "available_time")
    private Set<LocalTime> availableTimes = new HashSet<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public Set<LocalDate> getAvailableDates() {
		return availableDates;
	}

	public void setAvailableDates(Set<LocalDate> availableDates) {
		this.availableDates = availableDates;
	}

	public Set<LocalTime> getAvailableTimes() {
		return availableTimes;
	}

	public void setAvailableTimes(Set<LocalTime> availableTimes) {
		this.availableTimes = availableTimes;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

    
}
