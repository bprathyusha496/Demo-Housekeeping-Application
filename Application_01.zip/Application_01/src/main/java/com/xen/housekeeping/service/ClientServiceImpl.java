package com.xen.housekeeping.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xen.housekeeping.Entity.Client;
import com.xen.housekeeping.dto.ClientDTO;
import com.xen.housekeeping.repository.ClientRepository;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	private ClientRepository clientRepository;
	private final ModelMapper modelMapper;
	

	public ClientServiceImpl(ClientRepository clientRepository, ModelMapper modelMapper) {
		this.clientRepository = clientRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<ClientDTO> getAllClients() {
		List<Client> clients = clientRepository.findAll();
		return clients.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public ClientDTO createClient(ClientDTO clientDTO) {
		Client client = convertToEntity(clientDTO);
		Client savedClient = clientRepository.save(client);
		return convertToDTO(savedClient);
	}

	private ClientDTO convertToDTO(Client client) {
		return modelMapper.map(client, ClientDTO.class);
	}

	private Client convertToEntity(ClientDTO clientDTO) {
		return modelMapper.map(clientDTO, Client.class);
	}

	@Override
	public List<ClientDTO> getClientsByLocation(String location) {
		List<Client> clients = clientRepository.findByLocation(location);
		return clients.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<ClientDTO> getClientsWithOutstandingPayments() {
		List<Client> clients = clientRepository.findByOutstandingPaymentsGreaterThan(0.0);
		return clients.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<ClientDTO> getClientsWithNoFeedback() {
		List<Client> clients = clientRepository.findClientsWithNoFeedback();
		return clients.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

}
