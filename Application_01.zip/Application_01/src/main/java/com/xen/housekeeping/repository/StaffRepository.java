package com.xen.housekeeping.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xen.housekeeping.Entity.Staff;
import com.xen.housekeeping.dto.StaffDTO;

public interface StaffRepository extends JpaRepository<Staff, Long>{

	List<Staff> findByRole(String role);
	List<Staff> findBySkillsContaining(String skill);
	List<Staff> findByStatus(String status);
	List<Staff> findByWorkingHours(int hours);
	List<Staff> findByLocation(String location);
	
//	List<Staff> findByAvailability(LocalDate date);
//  List<Staff> findByAvailabilityStartDateAfter(LocalDate date);
//  List<Staff> findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate date);
//  List<Staff> findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate startDate, LocalDate endDate);
//  List<StaffDTO> findByAvailabilityStartDateBeforeAndAvailabilityEndDateAfter(LocalDate startDate, LocalDate endDate);

}
