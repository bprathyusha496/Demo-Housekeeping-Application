package com.xen.housekeeping.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xen.housekeeping.Entity.Task;
import com.xen.housekeeping.dto.TaskDTO;
import com.xen.housekeeping.repository.TaskRepository;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	private TaskRepository taskRepository;

	private final ModelMapper modelMapper;

	public TaskServiceImpl(TaskRepository taskRepository, ModelMapper modelMapper) {
		super();
		this.taskRepository = taskRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<TaskDTO> getAllTasks() {
		List<Task> tasks = taskRepository.findAll();
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	/*
	 * @Override public TaskDTO createTask(TaskDTO taskDTO) { Task task =
	 * convertToEntity(taskDTO); Task savedTask = taskRepository.save(task); return
	 * convertToDTO(savedTask); }
	 */
	@Override
    public TaskDTO createTask(TaskDTO taskDTO) {
        Task task = modelMapper.map(taskDTO, Task.class);
        Task savedTask = taskRepository.save(task);
        return modelMapper.map(savedTask, TaskDTO.class);
    }
	private TaskDTO convertToDTO(Task task) {
		return modelMapper.map(task, TaskDTO.class);
	}

	private Task convertToEntity(TaskDTO taskDTO) {
		return modelMapper.map(taskDTO, Task.class);
	}

	@Override
	public List<TaskDTO> getTasksByStaffId(Long staffId) {
		List<Task> tasks = taskRepository.findByStaffId(staffId);
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<TaskDTO> getTasksByClientId(Long clientId) {
		List<Task> tasks = taskRepository.findByClientId(clientId);
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<TaskDTO> getTasksCompletedBetween(LocalDate startDate, LocalDate endDate) {
		List<Task> tasks = taskRepository.findByCompletionDateBetween(startDate, endDate);
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public List<TaskDTO> getTasksCompletedByStaffWithinRange(Long staffId, LocalDate startDate, LocalDate endDate) {
		List<Task> tasks = taskRepository.findByStaffIdAndCompletionDateBetween(staffId, startDate, endDate);
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public Map<Long, Long> getTotalCompletedTasksByStaff() {
		List<Object[]> results = taskRepository.findTotalCompletedTasksByStaff();
		Map<Long, Long> tasksByStaff = new HashMap<>();
		for (Object[] result : results) {
			Long staffId = (Long) result[0];
			Long taskCount = (Long) result[1];
			tasksByStaff.put(staffId, taskCount);
		}
		return tasksByStaff;
	}

	@Override
	public List<TaskDTO> getOverdueTasks() {
		List<Task> tasks = taskRepository.findOverdueTasks();
		return tasks.stream().map(this::convertToDTO).collect(Collectors.toList());
	}

	@Override
	public Map<Long, Double> getAverageRatingsByClient() {
		List<Object[]> results = taskRepository.findAverageRatingsByClient();
		Map<Long, Double> averageRatingsByClient = new HashMap<>();
		for (Object[] result : results) {
			Long clientId = (Long) result[0];
			Double averageRating = (Double) result[1];
			averageRatingsByClient.put(clientId, averageRating);
		}
		return averageRatingsByClient;
	}

}
