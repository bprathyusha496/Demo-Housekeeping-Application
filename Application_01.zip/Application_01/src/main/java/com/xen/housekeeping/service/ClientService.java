package com.xen.housekeeping.service;

import java.util.List;

import com.xen.housekeeping.dto.ClientDTO;

public interface ClientService {

	List<ClientDTO> getAllClients();
    ClientDTO createClient(ClientDTO clientDTO);
    List<ClientDTO> getClientsByLocation(String location);
    List<ClientDTO> getClientsWithOutstandingPayments();
    List<ClientDTO> getClientsWithNoFeedback();



}
