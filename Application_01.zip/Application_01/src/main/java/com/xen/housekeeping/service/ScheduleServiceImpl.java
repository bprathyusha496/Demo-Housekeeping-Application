package com.xen.housekeeping.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xen.housekeeping.Entity.Schedule;
import com.xen.housekeeping.dto.ScheduleDTO;
import com.xen.housekeeping.repository.ScheduleRepository;

@Service
public class ScheduleServiceImpl implements ScheduleService {

    @Autowired
    private ScheduleRepository scheduleRepository;
    private final ModelMapper modelMapper;
    

    public ScheduleServiceImpl(ScheduleRepository scheduleRepository, ModelMapper modelMapper) {
		super();
		this.scheduleRepository = scheduleRepository;
		this.modelMapper = modelMapper;
	}

	@Override
    public List<ScheduleDTO> getAllSchedules() {
        List<Schedule> schedules = scheduleRepository.findAll();
        return schedules.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ScheduleDTO createSchedule(ScheduleDTO scheduleDTO) {
        Schedule schedule = convertToEntity(scheduleDTO);
        Schedule savedSchedule = scheduleRepository.save(schedule);
        return convertToDTO(savedSchedule);
    }

    private ScheduleDTO convertToDTO(Schedule schedule) {
        return modelMapper.map(schedule, ScheduleDTO.class);
    }

    private Schedule convertToEntity(ScheduleDTO scheduleDTO) {
        return modelMapper.map(scheduleDTO, Schedule.class);
    }
    @Override
    public List<ScheduleDTO> getSchedulesByTaskId(Long taskId) {
        List<Schedule> schedules = scheduleRepository.findByTaskId(taskId);
        return schedules.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

}